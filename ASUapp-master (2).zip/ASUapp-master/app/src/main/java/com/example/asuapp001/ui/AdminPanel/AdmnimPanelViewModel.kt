package com.example.asuapp001.ui.AdminPanel

import androidx.lifecycle.ViewModel

class AdmnimPanelViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}