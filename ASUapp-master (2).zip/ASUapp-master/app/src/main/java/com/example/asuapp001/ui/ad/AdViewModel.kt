package com.example.asuapp001.ui.ad

import androidx.lifecycle.ViewModel

class AdViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}