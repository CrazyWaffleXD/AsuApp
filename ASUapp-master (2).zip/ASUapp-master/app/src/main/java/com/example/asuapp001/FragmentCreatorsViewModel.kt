package com.example.asuapp001

import androidx.lifecycle.ViewModel

class FragmentCreatorsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}